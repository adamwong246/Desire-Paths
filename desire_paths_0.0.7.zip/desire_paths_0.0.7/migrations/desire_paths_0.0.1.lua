global.dirt = {} --Technically a v1.1.1 migration
global.flattening = nil