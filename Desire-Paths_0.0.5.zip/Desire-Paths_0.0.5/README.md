# Desire Paths
a fork of https://mods.factorio.com/mod/Dirt_Path

This makes the "decay" of soil a function of the speed and weight of your vehicle. So a big heavy tank at high speed will cause a more damage than just walking. 

Much thanks to mylon @ https://mods.factorio.com/user/Mylon and his work on https://mods.factorio.com/mod/Dirt_Path, on which this is heavily based.

![demo](https://github.com/adamwong246/Desire-Paths/blob/master/screenshot0.png)
![demo](https://github.com/adamwong246/Desire-Paths/blob/master/screenshot1.png)